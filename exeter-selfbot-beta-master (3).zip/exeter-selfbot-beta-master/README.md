# exeter-selfbot-beta
beta release version for my discord selfbot

basically has everything you need for a selfbot plus more has a built in antinuke and music player too

## Notable Features

```python
- snipe
- editsnipe
- antinuke
- musicplayer
- message logger
- mee6 auto level up
- nitro sniper
- giveaway sniper
- slotbot sniper
- image search
- image manipulation
- massreact
- copycat
- 24/7 yui kiss/hug
- many more
```

## Installation
To install the dependencies just do this
```python
pip install [dependency]
```

## Usage
put token in config folder and password if you want to steal other people's profile pictures
![download](https://user-images.githubusercontent.com/38389469/89217335-009a1800-d59a-11ea-9906-54a3ca97096e.png)
## bye
[Swag1400](https://media0.giphy.com/media/inctcuuIJ9PvG/giphy.gif)
